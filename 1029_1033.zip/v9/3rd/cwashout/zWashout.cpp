//
// File: zWashout.cpp
//
// Code generated for Simulink model 'zWashout'.
//
// Model version                  : 1.85
// Simulink Coder version         : 9.0 (R2018b) 24-May-2018
// C/C++ source code generated on : Mon Oct 16 14:12:23 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "zWashout.h"
#define NumBitsPerChar                 8U

// Private macros used by the generated code to access rtModel
#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

static real_T look1_binlx(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

// private model entry point functions
extern void zWashout_derivatives();
extern "C" {
  extern real_T rtGetInf(void);
  extern real32_T rtGetInfF(void);
  extern real_T rtGetMinusInf(void);
  extern real32_T rtGetMinusInfF(void);
}                                      // extern "C"
  extern "C"
{
  extern real_T rtInf;
  extern real_T rtMinusInf;
  extern real_T rtNaN;
  extern real32_T rtInfF;
  extern real32_T rtMinusInfF;
  extern real32_T rtNaNF;
  extern void rt_InitInfAndNaN(size_t realSize);
  extern boolean_T rtIsInf(real_T value);
  extern boolean_T rtIsInfF(real32_T value);
  extern boolean_T rtIsNaN(real_T value);
  extern boolean_T rtIsNaNF(real32_T value);
  typedef struct {
    struct {
      uint32_T wordH;
      uint32_T wordL;
    } words;
  } BigEndianIEEEDouble;

  typedef struct {
    struct {
      uint32_T wordL;
      uint32_T wordH;
    } words;
  } LittleEndianIEEEDouble;

  typedef struct {
    union {
      real32_T wordLreal;
      uint32_T wordLuint;
    } wordL;
  } IEEESingle;
}                                      // extern "C"

extern "C" {
  real_T rtInf;
  real_T rtMinusInf;
  real_T rtNaN;
  real32_T rtInfF;
  real32_T rtMinusInfF;
  real32_T rtNaNF;
}
  extern "C"
{
  extern real_T rtGetNaN(void);
  extern real32_T rtGetNaNF(void);
}                                      // extern "C"

extern "C" {
  //
  // Initialize rtInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real_T rtGetInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T inf = 0.0;
    if (bitsPerReal == 32U) {
      inf = rtGetInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0x7FF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      inf = tmpVal.fltVal;
    }

    return inf;
  }

  //
  // Initialize rtInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real32_T rtGetInfF(void)
  {
    IEEESingle infF;
    infF.wordL.wordLuint = 0x7F800000U;
    return infF.wordL.wordLreal;
  }

  //
  // Initialize rtMinusInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real_T rtGetMinusInf(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T minf = 0.0;
    if (bitsPerReal == 32U) {
      minf = rtGetMinusInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      minf = tmpVal.fltVal;
    }

    return minf;
  }

  //
  // Initialize rtMinusInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  real32_T rtGetMinusInfF(void)
  {
    IEEESingle minfF;
    minfF.wordL.wordLuint = 0xFF800000U;
    return minfF.wordL.wordLreal;
  }
}
  extern "C"
{
  //
  // Initialize the rtInf, rtMinusInf, and rtNaN needed by the
  // generated code. NaN is initialized as non-signaling. Assumes IEEE.
  //
  void rt_InitInfAndNaN(size_t realSize)
  {
    (void) (realSize);
    rtNaN = rtGetNaN();
    rtNaNF = rtGetNaNF();
    rtInf = rtGetInf();
    rtInfF = rtGetInfF();
    rtMinusInf = rtGetMinusInf();
    rtMinusInfF = rtGetMinusInfF();
  }

  // Test if value is infinite
  boolean_T rtIsInf(real_T value)
  {
    return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
  }

  // Test if single-precision value is infinite
  boolean_T rtIsInfF(real32_T value)
  {
    return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
  }

  // Test if value is not a number
  boolean_T rtIsNaN(real_T value)
  {
    boolean_T result = (boolean_T) 0;
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    if (bitsPerReal == 32U) {
      result = rtIsNaNF((real32_T)value);
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.fltVal = value;
      result = (boolean_T)((tmpVal.bitVal.words.wordH & 0x7FF00000) ==
                           0x7FF00000 &&
                           ( (tmpVal.bitVal.words.wordH & 0x000FFFFF) != 0 ||
                            (tmpVal.bitVal.words.wordL != 0) ));
    }

    return result;
  }

  // Test if single-precision value is not a number
  boolean_T rtIsNaNF(real32_T value)
  {
    IEEESingle tmp;
    tmp.wordL.wordLreal = value;
    return (boolean_T)( (tmp.wordL.wordLuint & 0x7F800000) == 0x7F800000 &&
                       (tmp.wordL.wordLuint & 0x007FFFFF) != 0 );
  }
}

extern "C" {
  //
  // Initialize rtNaN needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  real_T rtGetNaN(void)
  {
    size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
    real_T nan = 0.0;
    if (bitsPerReal == 32U) {
      nan = rtGetNaNF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF80000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      nan = tmpVal.fltVal;
    }

    return nan;
  }

  //
  // Initialize rtNaNF needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  real32_T rtGetNaNF(void)
  {
    IEEESingle nanF = { { 0 } };

    nanF.wordL.wordLuint = 0xFFC00000U;
    return nanF.wordL.wordLreal;
  }
}
  static real_T look1_binlx(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex)
{
  real_T frac;
  uint32_T iRght;
  uint32_T iLeft;
  uint32_T bpIdx;

  // Column-major Lookup 1-D
  // Search method: 'binary'
  // Use previous index: 'off'
  // Interpolation method: 'Linear point-slope'
  // Extrapolation method: 'Linear'
  // Use last breakpoint for index at or above upper limit: 'off'
  // Remove protection against out-of-range input in generated code: 'off'

  // Prelookup - Index and Fraction
  // Index Search method: 'binary'
  // Extrapolation method: 'Linear'
  // Use previous index: 'off'
  // Use last breakpoint for index at or above upper limit: 'off'
  // Remove protection against out-of-range input in generated code: 'off'

  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    // Binary Search
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  // Column-major Interpolation 1-D
  // Interpolation method: 'Linear point-slope'
  // Use last breakpoint for index at or above upper limit: 'off'
  // Overflow mode: 'wrapping'

  return (table[iLeft + 1U] - table[iLeft]) * frac + table[iLeft];
}

//
// This function updates continuous states using the ODE4 fixed-step
// solver algorithm
//
void zwashout::rt_ertODEUpdateContinuousStates(RTWSolverInfo
  *si )
{
  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE4_IntgData *id = (ODE4_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T temp;
  int_T i;
  int_T nXc = 25;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  zWashout_derivatives();

  // f1 = f(t + (h/2), y + (h/2)*f0)
  temp = 0.5 * h;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f0[i]);
  }

  rtsiSetT(si, t + temp);
  rtsiSetdX(si, f1);
  this->step();
  zWashout_derivatives();

  // f2 = f(t + (h/2), y + (h/2)*f1)
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f1[i]);
  }

  rtsiSetdX(si, f2);
  this->step();
  zWashout_derivatives();

  // f3 = f(t + h, y + h*f2)
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (h*f2[i]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f3);
  this->step();
  zWashout_derivatives();

  // tnew = t + h
  // ynew = y + (h/6)*(f0 + 2*f1 + 2*f2 + 2*f3)
  temp = h / 6.0;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + temp*(f0[i] + 2.0*f1[i] + 2.0*f2[i] + f3[i]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

// Model step function
void zwashout::step()
{
  real_T rtb_uDLookupTable3;
  real_T rtb_Gain2;
  real_T rtb_Add1[3];
  real_T X1[9];
  real_T tmp[9];
  int32_T i;
  real_T rateLimiterRate;
  real_T X1_tmp;
  real_T X1_tmp_0;
  real_T tmp_0;
  real_T tmp_1;
  if (rtmIsMajorTimeStep((&rtM))) {
    // set solver stop time
    rtsiSetSolverStopTime(&(&rtM)->solverInfo,(((&rtM)->Timing.clockTick0+1)*
      (&rtM)->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep((&rtM))) {
    (&rtM)->Timing.t[0] = rtsiGetT(&(&rtM)->solverInfo);
  }

  // Gain: '<Root>/Gain2' incorporates:
  //   TransferFcn: '<Root>/Transfer Fcn1'

  rtb_Gain2 = (0.0 * rtX.TransferFcn1_CSTATE[0] + 6.25 *
               rtX.TransferFcn1_CSTATE[1]) * -0.1020408163265306;

  // TransferFcn: '<Root>/Transfer Fcn5'
  rtb_uDLookupTable3 = 0.0 * rtX.TransferFcn5_CSTATE[0] + 6.25 *
    rtX.TransferFcn5_CSTATE[1];

  // RateLimiter: '<Root>/Rate Limiter1' incorporates:
  //   Gain: '<Root>/Gain1'
  //   Inport: '<Root>/lp_gain_pitch'
  //   Inport: '<Root>/lp_gain_roll'
  //   Product: '<Root>/Product5'
  //   Product: '<Root>/Product6'

  rtb_Add1[0] = rtb_Gain2 * rtU.lp_gain_roll;
  rtb_Add1[1] = 0.1020408163265306 * rtb_uDLookupTable3 * rtU.lp_gain_pitch;
  if (rtDW.LastMajorTime == (rtInf)) {
    rtDW.RateLimiter1[0] = rtb_Gain2 * rtU.lp_gain_roll;
    rtDW.RateLimiter1[1] = 0.1020408163265306 * rtb_uDLookupTable3 *
      rtU.lp_gain_pitch;
    rtDW.RateLimiter1[2] = 0.0;
  } else {
    rtb_uDLookupTable3 = (&rtM)->Timing.t[0] - rtDW.LastMajorTime;
    rtb_Gain2 = rtb_uDLookupTable3 * 0.1;
    rtb_uDLookupTable3 *= -0.1;
    rateLimiterRate = rtb_Add1[0] - rtDW.PrevY[0];
    if (rateLimiterRate > rtb_Gain2) {
      rtDW.RateLimiter1[0] = rtDW.PrevY[0] + rtb_Gain2;
    } else if (rateLimiterRate < rtb_uDLookupTable3) {
      rtDW.RateLimiter1[0] = rtDW.PrevY[0] + rtb_uDLookupTable3;
    } else {
      rtDW.RateLimiter1[0] = rtb_Add1[0];
    }

    rateLimiterRate = rtb_Add1[1] - rtDW.PrevY[1];
    if (rateLimiterRate > rtb_Gain2) {
      rtDW.RateLimiter1[1] = rtDW.PrevY[1] + rtb_Gain2;
    } else if (rateLimiterRate < rtb_uDLookupTable3) {
      rtDW.RateLimiter1[1] = rtDW.PrevY[1] + rtb_uDLookupTable3;
    } else {
      rtDW.RateLimiter1[1] = rtb_Add1[1];
    }

    if (0.0 - rtDW.PrevY[2] > rtb_Gain2) {
      rtDW.RateLimiter1[2] = rtDW.PrevY[2] + rtb_Gain2;
    } else if (0.0 - rtDW.PrevY[2] < rtb_uDLookupTable3) {
      rtDW.RateLimiter1[2] = rtDW.PrevY[2] + rtb_uDLookupTable3;
    } else {
      rtDW.RateLimiter1[2] = 0.0;
    }
  }

  // End of RateLimiter: '<Root>/Rate Limiter1'

  // Sum: '<Root>/Add1' incorporates:
  //   Constant: '<Root>/Constant3'
  //   Inport: '<Root>/dp_gain'
  //   Inport: '<Root>/in_pitch'
  //   Inport: '<Root>/in_roll'
  //   Integrator: '<Root>/Integrator7'
  //   Integrator: '<Root>/Integrator8'
  //   Integrator: '<Root>/Integrator9'
  //   Product: '<Root>/Product3'

  rtb_Add1[0] = (rtDW.RateLimiter1[0] + rtX.Integrator7_CSTATE) + rtU.dp_gain *
    rtU.in_roll;
  rtb_Add1[1] = (rtDW.RateLimiter1[1] + rtX.Integrator8_CSTATE) + rtU.dp_gain *
    rtU.in_pitch;
  rtb_Add1[2] = (rtDW.RateLimiter1[2] + rtX.Integrator9_CSTATE) + rtU.dp_gain *
    0.0;

  // MATLAB Function: '<S2>/MATLAB Function' incorporates:
  //   MATLAB Function: '<S1>/MATLAB Function'

  X1[0] = 1.0;
  X1[1] = 0.0;
  X1[2] = 0.0;
  rtb_Gain2 = std::sin(rtb_Add1[0]);
  X1_tmp = std::tan(rtb_Add1[1]);
  X1[3] = rtb_Gain2 * X1_tmp;
  rtb_uDLookupTable3 = std::cos(rtb_Add1[0]);
  X1[4] = rtb_uDLookupTable3;
  rateLimiterRate = std::cos(rtb_Add1[1]);
  X1_tmp_0 = 1.0 / rateLimiterRate;
  X1[5] = X1_tmp_0 * rtb_Gain2;
  X1[6] = rtb_uDLookupTable3 * X1_tmp;
  X1[7] = -rtb_Gain2;
  X1[8] = X1_tmp_0 * rtb_uDLookupTable3;

  // MATLAB Function: '<S1>/MATLAB Function'
  tmp[0] = rtb_uDLookupTable3 * rateLimiterRate;
  tmp[1] = rtb_Gain2 * rateLimiterRate;
  X1_tmp = std::sin(rtb_Add1[1]);
  tmp[2] = -X1_tmp;
  X1_tmp_0 = std::sin(rtb_Add1[2]);
  tmp_0 = std::cos(rtb_Add1[2]);
  tmp_1 = rtb_uDLookupTable3 * X1_tmp;
  tmp[3] = tmp_1 * X1_tmp_0 - rtb_Gain2 * tmp_0;
  X1_tmp *= rtb_Gain2;
  tmp[4] = X1_tmp * X1_tmp_0 + rtb_uDLookupTable3 * tmp_0;
  tmp[5] = rateLimiterRate * X1_tmp_0;
  tmp[6] = tmp_1 * tmp_0 + rtb_Gain2 * X1_tmp_0;
  tmp[7] = X1_tmp * tmp_0 - rtb_uDLookupTable3 * X1_tmp_0;
  tmp[8] = rateLimiterRate * tmp_0;
  for (i = 0; i < 3; i++) {
    // Product: '<Root>/Matrix Multiply1' incorporates:
    //   Inport: '<Root>/p'
    //   Inport: '<Root>/q'
    //   Inport: '<Root>/r'

    rtDW.MatrixMultiply1[i] = 0.0;
    rtDW.MatrixMultiply1[i] += X1[i] * rtU.p;
    rtDW.MatrixMultiply1[i] += X1[i + 3] * rtU.q;
    rtDW.MatrixMultiply1[i] += X1[i + 6] * rtU.r;

    // Sum: '<Root>/Sum1' incorporates:
    //   Inport: '<Root>/ax'
    //   Inport: '<Root>/ay'
    //   Inport: '<Root>/az'
    //   Product: '<Root>/Matrix Multiply'

    rtDW.Sum1[i] = (tmp[i + 3] * rtU.ay + tmp[i] * rtU.ax) + tmp[i + 6] * rtU.az;

    // Product: '<Root>/Product4' incorporates:
    //   Inport: '<Root>/angle_gain'
    //   Lookup_n-D: '<Root>/1-D Lookup Table'

    rtb_Add1[i] = look1_binlx(rtU.angle_gain * rtb_Add1[i],
      rtConstP.uDLookupTable_bp01Data, rtConstP.uDLookupTable_tableData, 4U);
  }

  // Outport: '<Root>/roll'
  rtY.roll = rtb_Add1[0];

  // Outport: '<Root>/pitch'
  rtY.pitch = rtb_Add1[1];

  // Outport: '<Root>/yaw'
  rtY.yaw = rtb_Add1[2];

  // TransferFcn: '<Root>/X hp'
  rtDW.Xhp = 0.0;
  rtDW.Xhp += -5.0 * rtX.Xhp_CSTATE[0];
  rtDW.Xhp += -6.25 * rtX.Xhp_CSTATE[1];
  rtDW.Xhp += rtDW.Sum1[0];

  // TransferFcn: '<Root>/x hp1'
  rtDW.xhp1 = 0.0;
  rtDW.xhp1 += -10.0 * rtX.xhp1_CSTATE;
  rtDW.xhp1 += rtDW.Xhp;

  // TransferFcn: '<Root>/X hp1'
  rtDW.Xhp1 = 0.0;
  rtDW.Xhp1 += -3.0 * rtX.Xhp1_CSTATE[0];
  rtDW.Xhp1 += -2.25 * rtX.Xhp1_CSTATE[1];
  rtDW.Xhp1 += rtDW.Sum1[1];

  // TransferFcn: '<Root>/y hp1'
  rtDW.yhp1 = 0.0;
  rtDW.yhp1 += -10.0 * rtX.yhp1_CSTATE;
  rtDW.yhp1 += rtDW.Xhp1;

  // TransferFcn: '<Root>/X hp2'
  rtDW.Xhp2 = 0.0;
  rtDW.Xhp2 += -5.0 * rtX.Xhp2_CSTATE[0];
  rtDW.Xhp2 += -6.25 * rtX.Xhp2_CSTATE[1];
  rtDW.Xhp2 += rtDW.Sum1[2];

  // TransferFcn: '<Root>/z hp1'
  rtDW.zhp1 = 0.0;
  rtDW.zhp1 += -10.0 * rtX.zhp1_CSTATE;
  rtDW.zhp1 += rtDW.Xhp2;

  // TransferFcn: '<Root>/phi hp'
  rtDW.phihp = 0.0;
  rtDW.phihp += -0.2 * rtX.phihp_CSTATE;
  rtDW.phihp += rtDW.MatrixMultiply1[0];

  // TransferFcn: '<Root>/psi hp'
  rtDW.psihp = 0.0;
  rtDW.psihp += -0.2 * rtX.psihp_CSTATE;
  rtDW.psihp += rtDW.MatrixMultiply1[2];

  // TransferFcn: '<Root>/the hp'
  rtDW.thehp = 0.0;
  rtDW.thehp += -0.2 * rtX.thehp_CSTATE;
  rtDW.thehp += rtDW.MatrixMultiply1[1];

  // Outport: '<Root>/X' incorporates:
  //   Inport: '<Root>/ax_gain'
  //   Integrator: '<Root>/Integrator2'
  //   Lookup_n-D: '<Root>/1-D Lookup Table1'
  //   Product: '<Root>/Product'

  rtY.X_l = look1_binlx(rtU.ax_gain * rtX.Integrator2_CSTATE, rtConstP.pooled9,
                        rtConstP.pooled8, 10U);

  // Outport: '<Root>/Y' incorporates:
  //   Inport: '<Root>/ay_gain'
  //   Integrator: '<Root>/Integrator4'
  //   Lookup_n-D: '<Root>/1-D Lookup Table2'
  //   Product: '<Root>/Product1'

  rtY.Y = look1_binlx(rtU.ay_gain * rtX.Integrator4_CSTATE, rtConstP.pooled9,
                      rtConstP.pooled8, 10U);

  // Outport: '<Root>/Z' incorporates:
  //   Inport: '<Root>/az_gain'
  //   Integrator: '<Root>/Integrator6'
  //   Lookup_n-D: '<Root>/1-D Lookup Table3'
  //   Product: '<Root>/Product2'

  rtY.Z = look1_binlx(rtU.az_gain * rtX.Integrator6_CSTATE, rtConstP.pooled9,
                      rtConstP.pooled8, 10U);

  // Integrator: '<Root>/Integrator1'
  rtDW.Integrator1 = rtX.Integrator1_CSTATE;

  // Integrator: '<Root>/Integrator3'
  rtDW.Integrator3 = rtX.Integrator3_CSTATE;

  // Integrator: '<Root>/Integrator5'
  rtDW.Integrator5 = rtX.Integrator5_CSTATE;
  if (rtmIsMajorTimeStep((&rtM))) {
    // Update for RateLimiter: '<Root>/Rate Limiter1'
    rtDW.PrevY[0] = rtDW.RateLimiter1[0];
    rtDW.PrevY[1] = rtDW.RateLimiter1[1];
    rtDW.PrevY[2] = rtDW.RateLimiter1[2];
    rtDW.LastMajorTime = (&rtM)->Timing.t[0];
  }                                    // end MajorTimeStep

  if (rtmIsMajorTimeStep((&rtM))) {
    rt_ertODEUpdateContinuousStates(&(&rtM)->solverInfo);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++(&rtM)->Timing.clockTick0;
    (&rtM)->Timing.t[0] = rtsiGetSolverStopTime(&(&rtM)->solverInfo);

    {
      // Update absolute timer for sample time: [0.01s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.01, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      (&rtM)->Timing.clockTick1++;
    }
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void zwashout::zWashout_derivatives()
{
  XDot *_rtXdot;
  _rtXdot = ((XDot *) (&rtM)->derivs);

  // Derivatives for Integrator: '<Root>/Integrator7'
  _rtXdot->Integrator7_CSTATE = rtDW.phihp;

  // Derivatives for Integrator: '<Root>/Integrator8'
  _rtXdot->Integrator8_CSTATE = rtDW.thehp;

  // Derivatives for Integrator: '<Root>/Integrator9'
  _rtXdot->Integrator9_CSTATE = rtDW.psihp;

  // Derivatives for TransferFcn: '<Root>/Transfer Fcn1' incorporates:
  //   Inport: '<Root>/ay'

  _rtXdot->TransferFcn1_CSTATE[0] = 0.0;
  _rtXdot->TransferFcn1_CSTATE[0] += -5.0 * rtX.TransferFcn1_CSTATE[0];
  _rtXdot->TransferFcn1_CSTATE[1] = 0.0;
  _rtXdot->TransferFcn1_CSTATE[0] += -6.25 * rtX.TransferFcn1_CSTATE[1];
  _rtXdot->TransferFcn1_CSTATE[1] += rtX.TransferFcn1_CSTATE[0];
  _rtXdot->TransferFcn1_CSTATE[0] += rtU.ay;

  // Derivatives for TransferFcn: '<Root>/Transfer Fcn5' incorporates:
  //   Inport: '<Root>/ax'

  _rtXdot->TransferFcn5_CSTATE[0] = 0.0;
  _rtXdot->TransferFcn5_CSTATE[0] += -5.0 * rtX.TransferFcn5_CSTATE[0];
  _rtXdot->TransferFcn5_CSTATE[1] = 0.0;
  _rtXdot->TransferFcn5_CSTATE[0] += -6.25 * rtX.TransferFcn5_CSTATE[1];
  _rtXdot->TransferFcn5_CSTATE[1] += rtX.TransferFcn5_CSTATE[0];
  _rtXdot->TransferFcn5_CSTATE[0] += rtU.ax;

  // Derivatives for TransferFcn: '<Root>/X hp'
  _rtXdot->Xhp_CSTATE[0] = 0.0;
  _rtXdot->Xhp_CSTATE[0] += -5.0 * rtX.Xhp_CSTATE[0];
  _rtXdot->Xhp_CSTATE[1] = 0.0;
  _rtXdot->Xhp_CSTATE[0] += -6.25 * rtX.Xhp_CSTATE[1];
  _rtXdot->Xhp_CSTATE[1] += rtX.Xhp_CSTATE[0];
  _rtXdot->Xhp_CSTATE[0] += rtDW.Sum1[0];

  // Derivatives for TransferFcn: '<Root>/x hp1'
  _rtXdot->xhp1_CSTATE = 0.0;
  _rtXdot->xhp1_CSTATE += -10.0 * rtX.xhp1_CSTATE;
  _rtXdot->xhp1_CSTATE += rtDW.Xhp;

  // Derivatives for TransferFcn: '<Root>/X hp1'
  _rtXdot->Xhp1_CSTATE[0] = 0.0;
  _rtXdot->Xhp1_CSTATE[0] += -3.0 * rtX.Xhp1_CSTATE[0];
  _rtXdot->Xhp1_CSTATE[1] = 0.0;
  _rtXdot->Xhp1_CSTATE[0] += -2.25 * rtX.Xhp1_CSTATE[1];
  _rtXdot->Xhp1_CSTATE[1] += rtX.Xhp1_CSTATE[0];
  _rtXdot->Xhp1_CSTATE[0] += rtDW.Sum1[1];

  // Derivatives for TransferFcn: '<Root>/y hp1'
  _rtXdot->yhp1_CSTATE = 0.0;
  _rtXdot->yhp1_CSTATE += -10.0 * rtX.yhp1_CSTATE;
  _rtXdot->yhp1_CSTATE += rtDW.Xhp1;

  // Derivatives for TransferFcn: '<Root>/X hp2'
  _rtXdot->Xhp2_CSTATE[0] = 0.0;
  _rtXdot->Xhp2_CSTATE[0] += -5.0 * rtX.Xhp2_CSTATE[0];
  _rtXdot->Xhp2_CSTATE[1] = 0.0;
  _rtXdot->Xhp2_CSTATE[0] += -6.25 * rtX.Xhp2_CSTATE[1];
  _rtXdot->Xhp2_CSTATE[1] += rtX.Xhp2_CSTATE[0];
  _rtXdot->Xhp2_CSTATE[0] += rtDW.Sum1[2];

  // Derivatives for TransferFcn: '<Root>/z hp1'
  _rtXdot->zhp1_CSTATE = 0.0;
  _rtXdot->zhp1_CSTATE += -10.0 * rtX.zhp1_CSTATE;
  _rtXdot->zhp1_CSTATE += rtDW.Xhp2;

  // Derivatives for TransferFcn: '<Root>/phi hp'
  _rtXdot->phihp_CSTATE = 0.0;
  _rtXdot->phihp_CSTATE += -0.2 * rtX.phihp_CSTATE;
  _rtXdot->phihp_CSTATE += rtDW.MatrixMultiply1[0];

  // Derivatives for TransferFcn: '<Root>/psi hp'
  _rtXdot->psihp_CSTATE = 0.0;
  _rtXdot->psihp_CSTATE += -0.2 * rtX.psihp_CSTATE;
  _rtXdot->psihp_CSTATE += rtDW.MatrixMultiply1[2];

  // Derivatives for TransferFcn: '<Root>/the hp'
  _rtXdot->thehp_CSTATE = 0.0;
  _rtXdot->thehp_CSTATE += -0.2 * rtX.thehp_CSTATE;
  _rtXdot->thehp_CSTATE += rtDW.MatrixMultiply1[1];

  // Derivatives for Integrator: '<Root>/Integrator2'
  _rtXdot->Integrator2_CSTATE = rtDW.Integrator1;

  // Derivatives for Integrator: '<Root>/Integrator4'
  _rtXdot->Integrator4_CSTATE = rtDW.Integrator3;

  // Derivatives for Integrator: '<Root>/Integrator6'
  _rtXdot->Integrator6_CSTATE = rtDW.Integrator5;

  // Derivatives for Integrator: '<Root>/Integrator1'
  _rtXdot->Integrator1_CSTATE = rtDW.xhp1;

  // Derivatives for Integrator: '<Root>/Integrator3'
  _rtXdot->Integrator3_CSTATE = rtDW.yhp1;

  // Derivatives for Integrator: '<Root>/Integrator5'
  _rtXdot->Integrator5_CSTATE = rtDW.zhp1;
}

// Model initialize function
void zwashout::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  {
    // Setup solver object
    rtsiSetSimTimeStepPtr(&(&rtM)->solverInfo, &(&rtM)->Timing.simTimeStep);
    rtsiSetTPtr(&(&rtM)->solverInfo, &rtmGetTPtr((&rtM)));
    rtsiSetStepSizePtr(&(&rtM)->solverInfo, &(&rtM)->Timing.stepSize0);
    rtsiSetdXPtr(&(&rtM)->solverInfo, &(&rtM)->derivs);
    rtsiSetContStatesPtr(&(&rtM)->solverInfo, (real_T **) &(&rtM)->contStates);
    rtsiSetNumContStatesPtr(&(&rtM)->solverInfo, &(&rtM)->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&rtM)->solverInfo, &(&rtM)
      ->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&rtM)->solverInfo, &(&rtM)
      ->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&rtM)->solverInfo, &(&rtM)
      ->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&rtM)->solverInfo, (&rtmGetErrorStatus((&rtM))));
    rtsiSetRTModelPtr(&(&rtM)->solverInfo, (&rtM));
  }

  rtsiSetSimTimeStep(&(&rtM)->solverInfo, MAJOR_TIME_STEP);
  (&rtM)->intgData.y = (&rtM)->odeY;
  (&rtM)->intgData.f[0] = (&rtM)->odeF[0];
  (&rtM)->intgData.f[1] = (&rtM)->odeF[1];
  (&rtM)->intgData.f[2] = (&rtM)->odeF[2];
  (&rtM)->intgData.f[3] = (&rtM)->odeF[3];
  getRTM()->contStates = ((X *) &rtX);
  rtsiSetSolverData(&(&rtM)->solverInfo, (void *)&(&rtM)->intgData);
  rtsiSetSolverName(&(&rtM)->solverInfo,"ode4");
  rtmSetTPtr(getRTM(), &(&rtM)->Timing.tArray[0]);
  (&rtM)->Timing.stepSize0 = 0.01;

  // InitializeConditions for Integrator: '<Root>/Integrator7'
  rtX.Integrator7_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator8'
  rtX.Integrator8_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator9'
  rtX.Integrator9_CSTATE = 0.0;

  // InitializeConditions for RateLimiter: '<Root>/Rate Limiter1'
  rtDW.LastMajorTime = (rtInf);

  // InitializeConditions for TransferFcn: '<Root>/Transfer Fcn1'
  rtX.TransferFcn1_CSTATE[0] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/Transfer Fcn5'
  rtX.TransferFcn5_CSTATE[0] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/X hp'
  rtX.Xhp_CSTATE[0] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/Transfer Fcn1'
  rtX.TransferFcn1_CSTATE[1] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/Transfer Fcn5'
  rtX.TransferFcn5_CSTATE[1] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/X hp'
  rtX.Xhp_CSTATE[1] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/x hp1'
  rtX.xhp1_CSTATE = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/X hp1'
  rtX.Xhp1_CSTATE[0] = 0.0;
  rtX.Xhp1_CSTATE[1] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/y hp1'
  rtX.yhp1_CSTATE = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/X hp2'
  rtX.Xhp2_CSTATE[0] = 0.0;
  rtX.Xhp2_CSTATE[1] = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/z hp1'
  rtX.zhp1_CSTATE = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/phi hp'
  rtX.phihp_CSTATE = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/psi hp'
  rtX.psihp_CSTATE = 0.0;

  // InitializeConditions for TransferFcn: '<Root>/the hp'
  rtX.thehp_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator2'
  rtX.Integrator2_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator4'
  rtX.Integrator4_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator6'
  rtX.Integrator6_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator1'
  rtX.Integrator1_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator3'
  rtX.Integrator3_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<Root>/Integrator5'
  rtX.Integrator5_CSTATE = 0.0;
}

// Constructor
zwashout::zwashout()
{
  // Currently there is no constructor body generated.
}

// Destructor
zwashout::~zwashout()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL * zwashout::getRTM()
{
  return (&rtM);
}

//
// File trailer for generated code.
//
// [EOF]
//
