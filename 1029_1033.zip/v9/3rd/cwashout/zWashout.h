﻿//
// File: zWashout.h
//
// Code generated for Simulink model 'zWashout'.
//
// Model version                  : 1.85
// Simulink Coder version         : 9.0 (R2018b) 24-May-2018
// C/C++ source code generated on : Mon Oct 16 14:12:23 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_zWashout_h_
#define RTW_HEADER_zWashout_h_
#include <stddef.h>
#include <cmath>
#include <string.h>
#ifndef zWashout_COMMON_INCLUDES_
# define zWashout_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 // zWashout_COMMON_INCLUDES_

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

// Forward declaration for rtModel
typedef struct tag_RTM RT_MODEL;

// Block signals and states (default storage) for system '<Root>'
typedef struct {
  real_T RateLimiter1[3];              // '<Root>/Rate Limiter1'
  real_T MatrixMultiply1[3];           // '<Root>/Matrix Multiply1'
  real_T Sum1[3];                      // '<Root>/Sum1'
  real_T PrevY[3];                     // '<Root>/Rate Limiter1'
  real_T Xhp;                          // '<Root>/X hp'
  real_T xhp1;                         // '<Root>/x hp1'
  real_T Xhp1;                         // '<Root>/X hp1'
  real_T yhp1;                         // '<Root>/y hp1'
  real_T Xhp2;                         // '<Root>/X hp2'
  real_T zhp1;                         // '<Root>/z hp1'
  real_T phihp;                        // '<Root>/phi hp'
  real_T psihp;                        // '<Root>/psi hp'
  real_T thehp;                        // '<Root>/the hp'
  real_T Integrator1;                  // '<Root>/Integrator1'
  real_T Integrator3;                  // '<Root>/Integrator3'
  real_T Integrator5;                  // '<Root>/Integrator5'
  real_T LastMajorTime;                // '<Root>/Rate Limiter1'
} DW;

// Continuous states (default storage)
typedef struct {
  real_T Integrator7_CSTATE;           // '<Root>/Integrator7'
  real_T Integrator8_CSTATE;           // '<Root>/Integrator8'
  real_T Integrator9_CSTATE;           // '<Root>/Integrator9'
  real_T TransferFcn1_CSTATE[2];       // '<Root>/Transfer Fcn1'
  real_T TransferFcn5_CSTATE[2];       // '<Root>/Transfer Fcn5'
  real_T Xhp_CSTATE[2];                // '<Root>/X hp'
  real_T xhp1_CSTATE;                  // '<Root>/x hp1'
  real_T Xhp1_CSTATE[2];               // '<Root>/X hp1'
  real_T yhp1_CSTATE;                  // '<Root>/y hp1'
  real_T Xhp2_CSTATE[2];               // '<Root>/X hp2'
  real_T zhp1_CSTATE;                  // '<Root>/z hp1'
  real_T phihp_CSTATE;                 // '<Root>/phi hp'
  real_T psihp_CSTATE;                 // '<Root>/psi hp'
  real_T thehp_CSTATE;                 // '<Root>/the hp'
  real_T Integrator2_CSTATE;           // '<Root>/Integrator2'
  real_T Integrator4_CSTATE;           // '<Root>/Integrator4'
  real_T Integrator6_CSTATE;           // '<Root>/Integrator6'
  real_T Integrator1_CSTATE;           // '<Root>/Integrator1'
  real_T Integrator3_CSTATE;           // '<Root>/Integrator3'
  real_T Integrator5_CSTATE;           // '<Root>/Integrator5'
} X;

// State derivatives (default storage)
typedef struct {
  real_T Integrator7_CSTATE;           // '<Root>/Integrator7'
  real_T Integrator8_CSTATE;           // '<Root>/Integrator8'
  real_T Integrator9_CSTATE;           // '<Root>/Integrator9'
  real_T TransferFcn1_CSTATE[2];       // '<Root>/Transfer Fcn1'
  real_T TransferFcn5_CSTATE[2];       // '<Root>/Transfer Fcn5'
  real_T Xhp_CSTATE[2];                // '<Root>/X hp'
  real_T xhp1_CSTATE;                  // '<Root>/x hp1'
  real_T Xhp1_CSTATE[2];               // '<Root>/X hp1'
  real_T yhp1_CSTATE;                  // '<Root>/y hp1'
  real_T Xhp2_CSTATE[2];               // '<Root>/X hp2'
  real_T zhp1_CSTATE;                  // '<Root>/z hp1'
  real_T phihp_CSTATE;                 // '<Root>/phi hp'
  real_T psihp_CSTATE;                 // '<Root>/psi hp'
  real_T thehp_CSTATE;                 // '<Root>/the hp'
  real_T Integrator2_CSTATE;           // '<Root>/Integrator2'
  real_T Integrator4_CSTATE;           // '<Root>/Integrator4'
  real_T Integrator6_CSTATE;           // '<Root>/Integrator6'
  real_T Integrator1_CSTATE;           // '<Root>/Integrator1'
  real_T Integrator3_CSTATE;           // '<Root>/Integrator3'
  real_T Integrator5_CSTATE;           // '<Root>/Integrator5'
} XDot;

// State disabled
typedef struct {
  boolean_T Integrator7_CSTATE;        // '<Root>/Integrator7'
  boolean_T Integrator8_CSTATE;        // '<Root>/Integrator8'
  boolean_T Integrator9_CSTATE;        // '<Root>/Integrator9'
  boolean_T TransferFcn1_CSTATE[2];    // '<Root>/Transfer Fcn1'
  boolean_T TransferFcn5_CSTATE[2];    // '<Root>/Transfer Fcn5'
  boolean_T Xhp_CSTATE[2];             // '<Root>/X hp'
  boolean_T xhp1_CSTATE;               // '<Root>/x hp1'
  boolean_T Xhp1_CSTATE[2];            // '<Root>/X hp1'
  boolean_T yhp1_CSTATE;               // '<Root>/y hp1'
  boolean_T Xhp2_CSTATE[2];            // '<Root>/X hp2'
  boolean_T zhp1_CSTATE;               // '<Root>/z hp1'
  boolean_T phihp_CSTATE;              // '<Root>/phi hp'
  boolean_T psihp_CSTATE;              // '<Root>/psi hp'
  boolean_T thehp_CSTATE;              // '<Root>/the hp'
  boolean_T Integrator2_CSTATE;        // '<Root>/Integrator2'
  boolean_T Integrator4_CSTATE;        // '<Root>/Integrator4'
  boolean_T Integrator6_CSTATE;        // '<Root>/Integrator6'
  boolean_T Integrator1_CSTATE;        // '<Root>/Integrator1'
  boolean_T Integrator3_CSTATE;        // '<Root>/Integrator3'
  boolean_T Integrator5_CSTATE;        // '<Root>/Integrator5'
} XDis;

#ifndef ODE4_INTG
#define ODE4_INTG

// ODE4 Integration Data
typedef struct {
  real_T *y;                           // output
  real_T *f[4];                        // derivatives
} ODE4_IntgData;

#endif

// Constant parameters (default storage)
typedef struct {
  // Expression: [-0.35, -0.3, 0.0, 0.3, 0.35]
  //  Referenced by: '<Root>/1-D Lookup Table'

  real_T uDLookupTable_tableData[5];

  // Expression: [-0.8, -0.3, 0.0, 0.3, 0.8]
  //  Referenced by: '<Root>/1-D Lookup Table'

  real_T uDLookupTable_bp01Data[5];

  // Pooled Parameter (Expression: tanh([-5:5]))
  //  Referenced by:
  //    '<Root>/1-D Lookup Table1'
  //    '<Root>/1-D Lookup Table2'
  //    '<Root>/1-D Lookup Table3'

  real_T pooled8[11];

  // Pooled Parameter (Expression: [-5:5])
  //  Referenced by:
  //    '<Root>/1-D Lookup Table1'
  //    '<Root>/1-D Lookup Table2'
  //    '<Root>/1-D Lookup Table3'

  real_T pooled9[11];
} ConstP;

// External inputs (root inport signals with default storage)
typedef struct {
  real_T ax;                           // '<Root>/ax'
  real_T ay;                           // '<Root>/ay'
  real_T az;                           // '<Root>/az'
  real_T p;                            // '<Root>/p'
  real_T q;                            // '<Root>/q'
  real_T r;                            // '<Root>/r'
  real_T in_roll;                      // '<Root>/in_roll'
  real_T in_pitch;                     // '<Root>/in_pitch'
  real_T ax_gain;                      // '<Root>/ax_gain'
  real_T ay_gain;                      // '<Root>/ay_gain'
  real_T az_gain;                      // '<Root>/az_gain'
  real_T angle_gain;                   // '<Root>/angle_gain'
  real_T dp_gain;                      // '<Root>/dp_gain'
  real_T lp_gain_pitch;                // '<Root>/lp_gain_pitch'
  real_T lp_gain_roll;                 // '<Root>/lp_gain_roll'
} ExtU;

// External outputs (root outports fed by signals with default storage)
typedef struct {
  real_T X_l;                          // '<Root>/X'
  real_T Y;                            // '<Root>/Y'
  real_T Z;                            // '<Root>/Z'
  real_T roll;                         // '<Root>/roll'
  real_T pitch;                        // '<Root>/pitch'
  real_T yaw;                          // '<Root>/yaw'
} ExtY;

// Real-time Model Data Structure
struct tag_RTM {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[25];
  real_T odeF[4][25];
  ODE4_IntgData intgData;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

// Constant parameters (default storage)
extern const ConstP rtConstP;

// Class declaration for model zWashout
class zwashout {
  // public data and function members
 public:
  // External inputs
  ExtU rtU;

  // External outputs
  ExtY rtY;

  // model initialize function
  void initialize();

  // model step function
  void step();

  // Constructor
  zwashout();

  // Destructor
  ~zwashout();

  // Real-Time Model get method
  RT_MODEL * getRTM();

  // private data and function members
 private:
  // Block signals and states
  DW rtDW;
  X rtX;                               // Block continuous states

  // Real-Time Model
  RT_MODEL rtM;

  // Continuous states update member function
  void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si );

  // Derivatives member function
  void zWashout_derivatives();
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<Root>/Gain12' : Eliminated nontunable gain of 1
//  Block '<Root>/Gain13' : Eliminated nontunable gain of 1
//  Block '<Root>/Gain14' : Eliminated nontunable gain of 1
//  Block '<Root>/Gain15' : Eliminated nontunable gain of 1
//  Block '<Root>/Gain4' : Eliminated nontunable gain of 1
//  Block '<Root>/Gain5' : Eliminated nontunable gain of 1


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'zWashout'
//  '<S1>'   : 'zWashout/Ls2'
//  '<S2>'   : 'zWashout/Ts'
//  '<S3>'   : 'zWashout/Ls2/MATLAB Function'
//  '<S4>'   : 'zWashout/Ts/MATLAB Function'

#endif                                 // RTW_HEADER_zWashout_h_

//
// File trailer for generated code.
//
// [EOF]
//
