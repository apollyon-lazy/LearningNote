//
// File: zWashout_data.cpp
//
// Code generated for Simulink model 'zWashout'.
//
// Model version                  : 1.85
// Simulink Coder version         : 9.0 (R2018b) 24-May-2018
// C/C++ source code generated on : Mon Oct 16 14:12:23 2023
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "zWashout.h"

// Constant parameters (default storage)
const ConstP rtConstP = {
  // Expression: [-0.35, -0.3, 0.0, 0.3, 0.35]
  //  Referenced by: '<Root>/1-D Lookup Table'

  { -0.35, -0.3, 0.0, 0.3, 0.35 },

  // Expression: [-0.8, -0.3, 0.0, 0.3, 0.8]
  //  Referenced by: '<Root>/1-D Lookup Table'

  { -0.8, -0.3, 0.0, 0.3, 0.8 },

  // Pooled Parameter (Expression: tanh([-5:5]))
  //  Referenced by:
  //    '<Root>/1-D Lookup Table1'
  //    '<Root>/1-D Lookup Table2'
  //    '<Root>/1-D Lookup Table3'

  { -0.99990920426259511, -0.999329299739067, -0.99505475368673046,
    -0.9640275800758169, -0.76159415595576485, 0.0, 0.76159415595576485,
    0.9640275800758169, 0.99505475368673046, 0.999329299739067,
    0.99990920426259511 },

  // Pooled Parameter (Expression: [-5:5])
  //  Referenced by:
  //    '<Root>/1-D Lookup Table1'
  //    '<Root>/1-D Lookup Table2'
  //    '<Root>/1-D Lookup Table3'

  { -5.0, -4.0, -3.0, -2.0, -1.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0 }
};

//
// File trailer for generated code.
//
// [EOF]
//
